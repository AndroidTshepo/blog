-- phpMyAdmin SQL Dump
-- version 4.4.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 01, 2016 at 01:21 AM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `blog`
--

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_10_12_000000_create_users_table', 1),
('2014_10_12_100000_create_password_resets_table', 1),
('2016_03_20_220612_create_posts_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE IF NOT EXISTS `posts` (
  `id` int(10) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `body`, `created_at`, `updated_at`) VALUES
(1, 'This is a blog post', 'Lorem ipsum dolor sit amet, the was my first post.', '2016-03-22 12:13:34', '2016-03-31 19:42:05'),
(2, 'Hi there ', 'Its me blogging ', '2016-03-22 12:14:36', '2016-03-22 12:14:36'),
(3, 'Hi MorCorp', 'Can i become a member too', '2016-03-22 19:15:14', '2016-03-22 19:15:14'),
(4, 'Late night post', 'I am falling aslip ', '2016-03-22 20:00:39', '2016-03-22 20:00:39'),
(5, 'Yes', 'Yessss', '2016-03-23 12:07:13', '2016-03-23 12:07:13'),
(8, 'Theresa Update On The Database', 'Database designer, developing the ERD and Procedures.', '2016-03-26 20:09:24', '2016-03-31 19:14:24'),
(9, 'Hello ', 'Hi we are almost home.', '2016-03-28 16:10:59', '2016-03-31 17:12:22'),
(10, 'test', 'I am testing this', '2016-03-30 12:41:12', '2016-03-31 12:29:28'),
(12, 'Test', 'Test', '2016-03-31 13:54:27', '2016-03-31 19:14:46');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'John', '', '', NULL, NULL, NULL),
(2, 'tshpo', 'tshepo@gmail.com', '$2y$10$uymax9TfpbR.Bgr0nIjeReiODQp3l7dIx7lyl934tOrPFCpKqq1pm', '0TUge8UwmyrotQTdNuK8lZI3a5IE0r8vgr9ZApfLquoQfLew0ZLAg294REAC', '2016-03-28 13:10:35', '2016-03-31 19:44:36'),
(3, 'John', 'john@gmail.com', '$2y$10$21.O4y/vOFsqBS0vSt1KOu.I0XKkmVruaxk7zQjUhBjUSkuZdxxgK', NULL, '2016-03-31 08:07:17', '2016-03-31 08:07:17'),
(7, 'test', 'test@gmail.com', '$2y$10$Os3Rb9CKpISpqOMn1h/pb.X4Z1u2kMbS8Wm07rQjUSMM1hKOh3GBy', 'M7kdnDBl0SFsu6XLB3CaqHm2Wm4Ewcfgz4A2KGspZv57H1PziHWvb5JkdXxb', '2016-03-31 08:13:30', '2016-03-31 17:33:56'),
(10, 'test', 'test@yahoo.com', '$2y$10$SnifZWalnYfeI/EaXBSwcuqZ9WV7Yax6sptW8ioq39tmPOntcqTcK', 'YPhlYl40QNvJdwdQX44g3oxQk3TgEPnO2oXuuODk5tisSqns0lI3DUftrP7q', '2016-03-31 09:45:51', '2016-03-31 19:26:08'),
(11, 'tshepo@gmail.com', 'info@morecorp.co.za', '$2y$10$BieT2tPwE7tcGRd46nbwAuZ2IL5GKuokdpirzsLESimWOeuwC9a4y', 'nF8LEeMUuDB0NP0EZR90BehFuRDLrq5vDLYmwJa7iFBCXyTEifcYoX9K3MGf', '2016-03-31 19:45:21', '2016-03-31 19:45:49');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`),
  ADD KEY `password_resets_token_index` (`token`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
